# AWS S3 + Route53 + Amplify + Fultter + Dart 構成
## 開発時コマンドサマリー
* 【開発端末でテスト実行】
  * `lib/main.dart`　の場合
    ```bash
    flutter pub get && flutter build web && flutter run -d chrome
    ```
  * `lib/top.dart`　の場合：dart ファイルの名前を指定
    ```bash
    APP_SOURCE_FILE_NAME=lib/top.dart
    ```
    ```bash
    flutter pub get && flutter build web --target=$APP_SOURCE_FILE_NAME && flutter run -d chrome --target=$APP_SOURCE_FILE_NAME
    ```
* 変更内容をリポジトリに登録
  ```bash
  cd $APP_ROOT && git add . && git commit -m "regular update" &&  git push -u origin main && flutter pub get
  ```
* 変更内容をリポジトリに登録＆ビルド＆開発端末で実行
  ```bash
  cd $APP_ROOT && git add . && git commit -m "regular update" && git push -u origin main && flutter pub get && flutter build web && flutter run -d chrome
  ```
* 新規にS3バケットを作成する
  * バケット名が`bucket-name1`の場合
    ```bash
    BUCKET_NAME=bucket-name1 && ./create_s3_bucket.sh $BUCKET_NAME
    ```
* ビルド＆S3バケットにアップロード
  ```bash
  flutter build web && aws s3 sync build/web s3://$BUCKET_NAME/ && aws s3 ls s3://$BUCKET_NAME/
  ```

* ビルドしたコンテンツをS3バケットにアップロードし、Amplifyアプリケーションにデプロイする
  ```bash
  APP_ID=aaaaaaaaaaaaaaa && APP_SOURCE_FILE_NAME=lib/top.dart && BUCKET_NAME=bucket-name1 && APP_BRUNCH=prod && flutter pub get && flutter build web --target=$APP_SOURCE_FILE_NAME && aws s3 sync build/web s3://$BUCKET_NAME && cd build/web && zip -r ../web_build.zip . && cd ../.. && aws s3 cp build/web_build.zip s3://$BUCKET_NAME/web_build.zip && aws s3 ls s3://$BUCKET_NAME/web_build.zip && aws amplify start-deployment --app-id $APP_ID --branch-name $APP_BRUNCH --source-url s3://$BUCKET_NAME/web_build.zip && aws amplify get-job --app-id $APP_ID --branch-name $APP_BRUNCH --job-id 1
  ```

---

## 定数
* 最初に必ず設定・実行
  ```bash
  UNIQUE_NAME=basicinfo4
  APP_SOURCE_FILE_NAME=lib/$UNIQUE_NAME.dart
  BUCKET_NAME=app-name1.$UNIQUE_NAME && REGION=us-east-1
  APP_NAME=user_registration_app && APP_ROOT=~/app/flutter/$APP_NAME
  BACKET_URL=http://$BUCKET_NAME.s3-website-$REGION.amazonaws.com
  HOST_NAME=latcoltd.net
  echo $UNIQUE_NAME
  echo $APP_SOURCE_FILE_NAME
  echo $BUCKET_NAME
  echo $APP_NAME
  echo $BACKET_URL
  echo $HOST_NAME
  ```
<details><summary>./create_s3_bucket.sh</summary>
  
  ```bash
  #!/bin/bash

  # 概要: S3バケットを作成し、バケットポリシーを設定する

  # 第1引数をバケット名として使用
  BACKET_NAME=$1
  REGION=us-east-1

  echo "バケット名: $BACKET_NAME"
  echo "リージョン: $REGION"

  # S3バケットを作成
  aws s3api create-bucket --bucket $BACKET_NAME --region $REGION

  # バケットの存在確認
  aws s3 ls | grep $BACKET_NAME

  # パブリックアクセスをすべてブロックをOFFにする
  aws s3api put-public-access-block --bucket $BACKET_NAME --public-access-block-configuration '{
    "BlockPublicAcls": false,
    "IgnorePublicAcls": false,
    "BlockPublicPolicy": false,
    "RestrictPublicBuckets": false
  }'

  # バケットポリシーを設定
  aws s3api put-bucket-policy --bucket $BACKET_NAME --policy '{
    "Version": "2012-10-17",
    "Statement": [
      {
        "Sid": "PublicReadGetObject",
        "Effect": "Allow",
        "Principal": "*",
        "Action": "s3:GetObject",
        "Resource": "arn:aws:s3:::'"$BACKET_NAME"'/*"
      }
    ]
  }'
</details>

## Flutterインストール手順
* macOSの場合：ターミナル上での操作
    * 参考資料：https://docs.flutter.dev/get-started/install/macos/mobile-ios?* tab=vscode
      * Apple Siliconの場合のみ
        ```bash
        sudo softwareupdate --install-rosetta --agree-to-license
        ```
* ダウンロード
  * Intel Processor : 
    * https://storage.googleapis.com/flutter_infra_release/releases/stable/macos/flutter_macos_3.24.3-stable.zip
  * Apple Silicon : 
    * https://storage.googleapis.com/flutter_infra_release/releases/stable/macos/flutter_macos_3.24.3-stable.zip
* インストールコマンド
  ```bash
  unzip ~/development/flutter_macos_3.24.3-stable.zip -d ~/development
  touch ~/.zshenv
  echo 'export PATH=$HOME/development/flutter/bin:$PATH' > ~/.zshenv && cat ~/.zshenv
  ```
* VSCodeでの操作
  * press Command + Shift + P
  * Command Palette, type flutter
  * Select Flutter: New Project.
* XCodeインストール
  * https://itunes.apple.com/jp/app/xcode/id497799835?ls=1&mt=12
  * 「App Storeを開きますか？」のダイアログが出てくるので「App Storeを開く」をクリック
* Xcodeビルド
  ```bash
  sudo sh -c 'xcode-select -s /Applications/Xcode.app/Contents/Developer && xcodebuild -runFirstLaunch'
  sudo xcodebuild -license
  xcodebuild -downloadPlatform iOS
  ```
* iOSシミュレーターが必要な場合のみ
  ```bash
  open -a Simulator
  ```
  * Display Size	Menu command	Keyboard shortcut
  * Small	Window > Physical Size	Cmd + 1
  * Moderate	Window > Point Accurate	Cmd + 2
  * HD accurate	Window > Pixel Accurate	Cmd + 3
  * Fit to screen	Window > Fit Screen	Cmd + 4
* その他開発環境のインストール
  ```bash
  sudo gem install cocoapods
  export PATH=$HOME/.gem/bin:$PATH
  flutter doctor
  flutter doctor -v
  ```
* Flutterプロジェクトの作成
  ```bash
  flutter create $APP_NAME
  cd $APP_NAME
  ```
* パッケージを追加
  <details><summary>$APP_NAME/pubspec.yaml</summary>

  ```yaml
  name: $APP_NAME
  description: A new Flutter project.

  environment:
    sdk: '^3.3.0'

  dependencies:
    flutter:
      sdk: flutter
    path_provider: ^2.0.11
  ```
  </details>
* 実装：
  * $APP_NAME/lib/main.dart
  * $APP_NAME/test/widget_test.dart
* テスト
  ```bash
  flutter pub get
  flutter test
  ```
    <details><summary>実行結果</summary>
    
    ```bash
    00:04 +1: All tests passed!  
    ```
    </details>
* Web向けビルド
  ```bash
  flutter build web
  ```
    <details><summary>成功した時のメッセージ</summary>

    ```bash
    Compiling lib/main.dart for the Web...
    ```
    </details>
* Webブラウザで実行
  ```bash
  flutter run -d chrome
  ```
* 開発時gitコマンド
  * 初期化
    ```bash
    git init && git add . && git commit -m "regular update"
    git remote add origin https://github.com/git-git/$APP_NAME.git
    git remote -v
    git config --global http.postBuffer 524288000
    git push -u origin main
    ```
  * 通常時
    ```bash
    git add . && git commit -m "regular update" && git push -u origin main
    ```

## 実装コード

## S3へのデプロイ
以下の条件で新規にAWS の S3バケットを作成するAWS CLIコマンド
* リージョン：us-east-1
* バケット名 : $BUCKET_NAME
* パブリックアクセスをすべてブロック：OFF
* 静的ウェブサイトホスティング : 有効にする
* インデックスドキュメント : index.html
  * バケット作成コマンド
    ```bash
    # 定数設定
    # S3バケットを作成
    # バケットの存在確認
    # パブリックアクセスをすべてブロックをOFFにする
    # 静的ウェブサイトホスティングを有効にする
    BUCKET_NAME=app-name1.indiv-basic-info && REGION=us-east-1
    echo $BUCKET_NAME && echo $REGION
    aws s3api create-bucket --bucket $BUCKET_NAME --region $REGION
    aws s3 ls | grep $BUCKET_NAME
    aws s3api put-public-access-block --bucket $BUCKET_NAME --public-access-block-configuration BlockPublicAcls=false,IgnorePublicAcls=false,BlockPublicPolicy=false,RestrictPublicBuckets=false
    aws s3 website s3://$BUCKET_NAME/ --index-document index.html --error-document error.html
    ```
  <details><summary>実行結果</summary>

  ```json
  {
      "Location": "/$BUCKET_NAME"
  }
  ```
</details>

* S3 Bucket Polcy : allow access public http
  <details><summary>コマンド</summary>

    ```bash
    aws s3api put-bucket-policy --bucket $BUCKET_NAME --policy '{
      "Version": "2012-10-17",
      "Statement": [
          {
              "Sid": "PublicReadGetObject",
              "Effect": "Allow",
              "Principal": "*",
              "Action": "s3:GetObject",
              "Resource": "arn:aws:s3:::'$BUCKET_NAME'/*",
              "Condition": {
                  "Bool": {
                      "aws:SecureTransport": "false"
                  }
              }
          }
      ]
    }'
    ```
  </details>
* バケットのパブリックアクセス設定を確認し、必要に応じて更新します
  ```bash
  aws s3api put-public-access-block --bucket app-name1.user-registration --public-access-block-configuration '{
    "BlockPublicAcls": false,
    "IgnorePublicAcls": false,
    "BlockPublicPolicy": false,
    "RestrictPublicBuckets": false
  }'
  ```
* Backet Cross-Origine Resource Sharring(CROS)
  <details><summary>コマンド</summary>

    ```bash
    aws s3api put-bucket-cors --bucket $BUCKET_NAME --cors-configuration  '{
      "CORSRules": [
        {
          "AllowedHeaders": [
            "*"
          ],
          "AllowedMethods": [
            "GET","PUT","POST","DELETE","HEAD"
          ],
          "AllowedOrigins": [
            "*"
          ],
          "ExposeHeaders": []
        }
      ]
    }'
    ```
  </details>

## S3バケットへのコンテンツのアップロード
* 単純コピーの場合
  ```bash
  cd $APP_ROOT && flutter build web
  aws s3 ls s3://$BUCKET_NAME/
  aws s3 cp build/web/ s3://$BUCKET_NAME/ --recursive
  ```
* ローカルディレクトリbuild/webの内容をS3バケットs3://$BUCKET_NAME/に同期し、アップロードされたファイルのアクセス権限をパブリックリードに設定する場合
  ```bash
  cd $APP_ROOT && flutter build web
  aws s3api put-bucket-policy --bucket $BUCKET_NAME --policy '{
      "Version": "2012-10-17",
      "Statement": [
          {
              "Sid": "PublicReadGetObject",
              "Effect": "Allow",
              "Principal": "*",
              "Action": "s3:GetObject",
              "Resource": "arn:aws:s3:::'$BUCKET_NAME'/*"
          }
      ]
  }'
  aws s3 sync build/web s3://$BUCKET_NAME/
  aws s3 ls s3://$BUCKET_NAME/
  ```
  <details><summay>実行結果</summary>

  ```bash
  Warning: In index.html:37: Local variable for "serviceWorkerVersion" is deprecated. Use "{{flutter_service_worker_version}}" template token instead. See
  https://docs.flutter.dev/platform-integration/web/initialization for more details.
  Warning: In index.html:46: "FlutterLoader.loadEntrypoint" is deprecated. Use "FlutterLoader.load"
  instead. See https://docs.flutter.dev/platform-integration/web/initialization for more details.
  Compiling lib/main.dart for the Web...                             698ms
  ✓ Built build/web
  upload: build/web/assets/FontManifest.json to s3://$BUCKET_NAME/assets/FontManifest.json
  ・・・省略・・・
  upload: build/web/.last_build_id to s3://$BUCKET_NAME/.last_build_id
  upload: build/web/canvaskit/canvaskit.wasm to s3://$BUCKET_NAME/canvaskit/canvaskit.wasm
  ```
  </details>

## 動作確認
* バケットウェブサイトエンドポイントURLを得るコマンド
  ```bash
  BACKET_URL=http://$BUCKET_NAME.s3-website-$REGION.amazonaws.com
  echo $BACKET_URL
  ```

## `'YOUR_ACCESS_KEY'` と `'YOUR_SECRET_KEY'` の取得

AWSのアクセスキーとシークレットキーです。これらはAWSマネジメントコンソールから取得できます。以下の手順に従ってください。

### 手順
1. **AWSマネジメントコンソールにログイン**
   - [AWSマネジメントコンソール](https://aws.amazon.com/jp/console/)にアクセスし、ログインします。

2. **IAM（Identity and Access Management）サービスに移動**
   - コンソールの上部にある検索バーに「IAM」と入力し、IAMサービスに移動します。

3. **新しいユーザーを作成**
   - 左側のナビゲーションペインで「ユーザー」を選択し、「ユーザーを追加」ボタンをクリックします。
   - ユーザー名を入力し、「プログラムによるアクセス」にチェックを入れます。

4. **アクセス権限を設定**
   - 「次のステップ: アクセス権限」をクリックし、適切なアクセス権限をユーザーに付与します。
   - 「既存のポリシーを直接アタッチ」を選択し、「AmazonDynamoDBFullAccess」などの適切なポリシーを選択します。

5. **タグ（オプション）を設定**
   - 必要に応じてタグを追加します（オプション）。

6. **確認と作成**
   - 設定内容を確認し、「ユーザーを作成」ボタンをクリックします。

7. **アクセスキーとシークレットキーを取得**
   - ユーザーが作成されると、アクセスキーIDとシークレットアクセスキーが表示されます。
   - これらの情報を安全な場所に保存してください。シークレットキーはこの画面でしか表示されないため、必ず保存してください。

## S3バケットを削除

### 手順

1. **バケット内のオブジェクトを削除**
   ```bash
   aws s3 rm s3://$BUCKET_NAME --recursive
   ```

2. **バケットを削除**
   ```bash
   aws s3api delete-bucket --bucket $BUCKET_NAME --region us-east-1
   ```

### 取得したキーをコードに設定
取得したアクセスキーとシークレットキーをコードに設定します。

```dart
final awsSigV

Client = AWSSigV4Client(
  'YOUR_ACCESS_KEY',  // 取得したアクセスキーID
  'YOUR_SECRET_KEY',  // 取得したシークレットアクセスキー
  'https://dynamodb.ap-northeast-1.amazonaws.com',
  region: 'ap-northeast-1',
);
```

これで、DynamoDBにアクセスするための認証情報が設定され、リクエストが成功するはずです。

## Amplifyでの公開手順

1. **AmplifyアプリケーションにS3バケットを追加する**:
  ```sh
  APP_ID=aaaaaaaaaaaaaaa && APP_BRUNCH=prod && aws amplify create-backend-environment --app-id aaaaaaaaaaaaaaa --environment-name $APP_BRUNCH --stack-name amplify-lat-top --deployment-artifacts lat-top
  ```
  <details><summary>実行結果</summary>

    ```json
    {
        "backendEnvironment": {
            "backendEnvironmentArn": "arn:aws:amplify:us-east-1:12345678901:apps/aaaaaaaaaaaaaaa/backendenvironments/prod",
            "environmentName": "prod",
            "stackName": "amplify-lat-top",
            "deploymentArtifacts": "lat-top",
            "createTime": "2024-12-06T00:52:31.120000+09:00",
            "updateTime": "2024-12-06T00:52:31.120000+09:00"
        }
    }
    ```
   </details>

2. **S3バケットを作成し、ウェブサイトホスティングを設定する**:
  ```sh
  aws s3api create-bucket --bucket lat-top --region us-east-1
  aws s3 website s3://lat-top/ --index-document index.html --error-document error.html
  ```

3. バケットのパブリックアクセスブロック設定を無効にする:
  ```sh
  aws s3api put-public-access-block --bucket lat-top --public-access-block-configuration '{
    "BlockPublicAcls": false,
    "IgnorePublicAcls": false,
    "BlockPublicPolicy": false,
    "RestrictPublicBuckets": false
  }'
  ```

3. **バケットポリシーを設定して、バケットをパブリックにする**:
  ```sh
  aws s3api put-bucket-policy --bucket lat-top --policy '{
    "Version": "2012-10-17",
    "Statement": [
      {
        "Sid": "PublicReadGetObject",
        "Effect": "Allow",
        "Principal": "*",
        "Action": "s3:GetObject",
        "Resource": "arn:aws:s3:::lat-top/*"
      }
    ]
  }'
  ```
4. Amplifyアプリケーションにブランチを作成する:
  ```bash
  APP_ID=aaaaaaaaaaaaaaa && APP_BRUNCH=prod && aws amplify create-branch --app-id $APP_ID --branch-name $APP_BRUNCH
  ```
5. **カスタムドメインを追加する**:
  * **DNS設定を確認する**:
    * ドメインのDNS設定を確認し、提供されたCNAMEレコードをドメインのDNSプロバイダーに追加します。これにより、`latcoltd.net`がAmplifyアプリケーションにマッピングされます。
  * **DNSプロバイダーにCNAMEレコードを追加する**:
    ドメインのDNSプロバイダー（例: Route 53、GoDaddyなど）にログインし、提供されたCNAMEレコードを追加します。
  * **ドメインの検証を待つ**:
    * DNS設定が反映されるまで数分から数時間かかることがあります。設定が正しく行われていれば、`https://latcoltd.net/`がAmplifyアプリケーションにマッピングされます。
  * ルートブランチの場合
    ```bash
    aws amplify create-domain-association --app-id $APP_ID --domain-name latcoltd.net --sub-domain-settings '[{"prefix": "", "branchName": "'$APP_BRUNCH'"}]'
    ```
  * サブブランチの場合
    ```bash
    aws amplify create-domain-association --app-id $APP_ID --domain-name latcoltd.net --sub-domain-settings '[{"prefix": "'$APP_BRUNCH'", "branchName": "'$APP_BRUNCH'"}]'
    ```
  <details><summary>実行結果</summary>

  ```json
  {
    "branch": {
        "branchArn": "arn:aws:amplify:us-east-1:12345678901:apps/aaaaaaaaaaaaaaa/branches/prod",
        "branchName": "prod",
        "stage": "NONE",
        "displayName": "prod",
        "enableNotification": false,
        "createTime": "2024-12-06T00:55:39.107000+09:00",
        "updateTime": "2024-12-06T00:55:39.107000+09:00",
        "enableAutoBuild": true,
        "totalNumberOfJobs": "0",
        "enableBasicAuth": false,
        "enablePerformanceMode": false,
        "ttl": "5",
        "enablePullRequestPreview": false,
        "backend": {}
    }
  }
  {
      "domainAssociation": {
          "domainAssociationArn": "arn:aws:amplify:us-east-1:12345678901:apps/aaaaaaaaaaaaaaa/domains/latcoltd.net",
          "domainName": "latcoltd.net",
          "enableAutoSubDomain": false,
          "domainStatus": "CREATING",
          "subDomains": [
              {
                  "subDomainSetting": {
                      "prefix": "",
                      "branchName": "prod"
                  },
                  "verified": false,
                  "dnsRecord": "* CNAME <pending>"
              }
          ]
      }
  }
  ```
  </details>

6. **`$APP_SOURCE_FILE_NAME`をエントリーポイントとしてビルドする**:
  ```sh
  flutter build web --target=$APP_SOURCE_FILE_NAME
  ```
7. **ビルドされた内容をS3バケットに同期する**:
  ```sh
  aws s3 sync build/web s3://$BUCKET_NAME
  ```

8. **ビルドされた内容をZIPファイルに圧縮する**:
  ```sh
  cd build/web && zip -r ../web_build.zip . && cd ../..
  ```

9. **ZIPファイルをS3バケットにアップロードする**:
  ```sh
  aws s3 cp build/web_build.zip s3://$BUCKET_NAME/web_build.zip && aws s3 ls s3://$BUCKET_NAME/web_build.zip
  ```

10. **Amplifyアプリケーションにデプロイする**:
  ```sh
  aws amplify start-deployment --app-id $APP_ID --branch-name $APP_BRUNCH --source-url s3://$BUCKET_NAME/web_build.zip
  aws amplify get-job --app-id $APP_ID --branch-name $APP_BRUNCH --job-id 1
  ```
  <details><summary>実行結果</summary>

  ```json
  {
    "job": {
        "summary": {
            "jobArn": "arn:aws:amplify:us-east-1:12345678901:apps/aaaaaaaaaaaaaaa/branches/prod/jobs/0000000001",
            "jobId": "1",
            "startTime": "2024-12-06T00:59:58.679000+09:00",
            "status": "SUCCEED",
            "endTime": "2024-12-06T01:00:01.068000+09:00"
        },
       "steps": [
            {
                "stepName": "DEPLOY",
                "startTime": "2024-12-06T00:59:58.697000+09:00",
                "status": "SUCCEED",
                "endTime": "2024-12-06T01:00:00.839000+09:00",
                "logUrl": "https://aws-amplify-prod-us-east-1-artifacts.s3.us-east-1.amazonaws.com/aaaaaaaaaaaaaaa/prod/0000000001/DEPLOY/log.txt?
                ..................._request&X-Amz-Signature=efc8de66ced67921b8a48e3f3de9c52d8bb9251b1cbc793cd84bae689b03cab6",
                "artifactsUrl": "https://aws-amplify-prod-us-east-1-artifacts.s3.us-east-1.amazonaws.com/aaaaaaaaaaaaaaa/prod/0000000001/DEPLOY/artifacts.zip?・・・・"
            },
            {
                "stepName": "VERIFY",
                "startTime": "2024-12-06T01:00:00.943000+09:00",
                "status": "SUCCEED",
                "endTime": "2024-12-06T01:00:00.960000+09:00",
  }
  ```
  </details>

## Amplify Backend 編集
バックエンドでの作業を続行するには、Amplify CLI をインストールし、プロジェクトフォルダのルートから次のコマンドを実行して更新を行います。
  ```bash
  amplify pull --appId aaaaaaaaaaaaaaa --envName dev
  ```
  <details><summary>実行結果</summary>

  ```bash
  Pre-pull status:

      Current Environment: dev
      
  ┌──────────┬────────────────┬───────────┬───────────────────┐
  │ Category │ Resource name  │ Operation │ Provider plugin   │
  ├──────────┼────────────────┼───────────┼───────────────────┤
  │ Hosting  │ amplifyhosting │ No Change │ awscloudformation │
  └──────────┴────────────────┴───────────┴───────────────────┘

  ✔ Successfully pulled backend environment dev from the cloud.
  ✅ 
  Post-pull status:

      Current Environment: dev
      
  ┌──────────┬────────────────┬───────────┬───────────────────┐
  │ Category │ Resource name  │ Operation │ Provider plugin   │
  ├──────────┼────────────────┼───────────┼───────────────────┤
  │ Hosting  │ amplifyhosting │ No Change │ awscloudformation │
  └──────────┴────────────────┴───────────┴───────────────────┘
  ```
  </details>

## Ampify CLI のインストール

1. **Amplify CLIをインストールする**（まだインストールしていない場合）:
   ```sh
   npm install -g @aws-amplify/cli
   ```

2. **Amplifyプロジェクトを初期化する**:
   ```sh
   amplify init
   ```

3. **ホスティングを追加する**:
   ```sh
   amplify add hosting
   ```

4. **プロジェクトをデプロイする**:
   ```sh
   amplify publish
   ```

これにより、AmplifyプロジェクトがS3バケットにデプロイされ、ホスティングが設定されます。

## Route 53 でWebページを公開する
* 以下の手順で、AWS CLIを使用してS3バケットをRoute 53のドメインに設定することができます。

### 手順
1. **ホストゾーンIDの取得**
   ```bash
   HOSTED_ZONE_ID=$(aws route53 list-hosted-zones-by-name --dns-name latcoltd.net --query "HostedZones[0].Id" --output text) && echo $HOSTED_ZONE_ID
   ```

2. **Route 53にレコードを作成**
  ```bash
  aws route53 change-resource-record-sets --hosted-zone-id $HOSTED_ZONE_ID --change-batch '{
    "Changes": [{
      "Action": "UPSERT",
      "ResourceRecordSet": {
        "Name": "latcoltd.net",
        "Type": "A",
        "AliasTarget": {
          "HostedZoneId": "AAAAAAAAAAAAA",
          "DNSName": "bucket-name1.s3-website-us-east-1.amazonaws.com",
          "EvaluateTargetHealth": false
        }
      }
    }]
  }'
  ```
  * 実行結果
    ```json
    {
        "ChangeInfo": {
            "Id": "/change/AAAAAAAAAAAAA",
            "Status": "PENDING",
            "SubmittedAt": "2024-12-03T08:39:01.952000+00:00"
        }
    }
    ```
  * 変更ステータスの確認
    ```bash
    aws route53 get-change --id /change/AAAAAAAAAAAAA
    nslookup latcoltd.net
    host latcoltd.net
    aws route53 list-resource-record-sets --hosted-zone-id $HOSTED_ZONE_ID
    sudo dscacheutil -flushcache; sudo killall -HUP mDNSResponder
    aws s3 website s3://$BUCKET_NAME/ --index-document index.html --error-document error.html
    dig latcoltd.net
    ```

### 注意点
- `AAAAAAAAAAAAA`は、us-east-1リージョンのS3ウェブサイトホスティングのHostedZoneIdです。他のリージョンの場合は異なる可能性があります。

これにより、`http://latcoltd.net/`にアクセスすると、S3バケットのURLが表示されるようになります。
